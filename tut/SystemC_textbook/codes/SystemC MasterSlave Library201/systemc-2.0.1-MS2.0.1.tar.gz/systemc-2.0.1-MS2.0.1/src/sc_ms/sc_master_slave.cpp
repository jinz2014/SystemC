/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2002 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.2 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

/*****************************************************************************

  sc_master_slave.cpp -- Master / Slave ports.

  Original Author: Dirk Vermeersch, Coware, Inc.
                   Vijay Kumar, Coware, Inc.

*****************************************************************************/

#include "sc_ms/sc_slave_process.h"
#include "sc_ms/sc_master_slave.h"
#include "sc_ms/sc_master_slave_utils.h"
#include "sc_ms/sc_ms_ids.h"

static sc_pvector< sc_slave_handle >	process_table;
const char* const 			sc_slave_process::kind_string = "sc_slave_process";
sc_self_binding_port* 			current_port_protocol=0;


// register the slave process
sc_slave_handle 
register_slave_process( const char* name,
                         SC_ENTRY_FUNC entry_fn,
                         sc_module* module )
{
  sc_slave_handle handle = new sc_slave_process( name,
						 entry_fn,
						 module );
  process_table.push_back( handle );
  return handle;
}


void execute_slave_process( sc_slave_handle handle )
{
  handle->execute( );
}

sc_self_binding_port_binder::sc_self_binding_port_binder( 
  sc_self_binding_port& lhs, 
  sc_self_binding_port& rhs )
{
  if ( lhs.get_address_index( ) != rhs.get_address_index( ) ) {
    char buf[ERROR_MSG_BUF_SIZE];
    sprintf( buf, 
	     "number of address terminals of port %s and %s must be same. "
	     "  Port %s has %d terminals and Port %s has %d terminals.", 
	     lhs.name( ), rhs.name( ), 
	     lhs.name( ), lhs.get_address_index( ),
	     rhs.name( ), rhs.get_address_index( ) );
    SC_REPORT_ERROR(SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, buf );
    return;
  }

  if ( lhs.get_control_index( ) != rhs.get_control_index( ) ) {
    char buf[ERROR_MSG_BUF_SIZE];
    sprintf( buf, 
	     "number of control terminals of port %s and %s must be same. "
	     "  Port %s has %d terminals and Port %s has %d terminals.", 
	     lhs.name( ), rhs.name( ), 
	     lhs.name( ), lhs.get_address_index( ),
	     rhs.name( ), rhs.get_address_index( ) );
    SC_REPORT_ERROR(SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, buf );
    return;
  }
  
  if ( lhs.get_data_index( ) != rhs.get_data_index( ) ) {
    char buf[ERROR_MSG_BUF_SIZE];
    sprintf( buf, 
	     "number of data terminals of port %s and %s must be same. "
	     "  Port %s has %d terminals and Port %s has %d terminals.", 
	     lhs.name( ), rhs.name( ), 
	     lhs.name( ), lhs.get_address_index( ),
	     rhs.name( ), rhs.get_address_index( ) );
    SC_REPORT_ERROR(SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, buf );
    return;
  }
  bind_terminals( lhs.data_terminals, rhs.data_terminals );
  bind_terminals( lhs.address_terminals, rhs.address_terminals );
  bind_terminals( lhs.control_terminals, rhs.control_terminals );
}

// bind both sets of terminals to each other.  This is used by
// port to port binding of refined terminals
void
sc_self_binding_port_binder::bind_terminals( terminals& lhs,
                                             terminals& rhs )
{
  if ( lhs.count( ) != rhs.count( ) ) {
      SC_REPORT_ERROR( SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, 
                       "cannot bind terminals of self binding ports"
                       ", terminal sizes are not same" );
  }

  for ( terminals::iterator 
	lhs_it( lhs ), rhs_it( rhs ) ; 
       !lhs_it.empty( ) ; 
       lhs_it++, rhs_it++ ) {
    sc_self_binding_terminal_b* lhs_terminal = lhs_it.contents( );
    sc_self_binding_terminal_b* rhs_terminal = rhs_it.contents( );

    lhs_terminal->bind( rhs_terminal );
  } // for
}


//-----------------------------------------------------------------------
void  
sc_self_binding_port::add_terminal_b(sc_self_binding_terminal_b* intf, int id ) {
  switch( intf->get_terminal_type( ) ) {
  case TT_DATA:
    add_terminal( data_terminals, intf , id );
    break;
  
  case TT_ADDRESS:
    add_terminal( address_terminals, intf , id );
    break;
  
  case TT_CONTROL:
    add_terminal( control_terminals, intf, id );
    break;
  } // switch
}

//-----------------------------------------------------------------------
void
sc_self_binding_port::add_terminal( terminals& the_list,
                                       sc_self_binding_terminal_b* intf, 
                                       int id ) 
{
  sc_self_binding_terminal_b** result = 0;
  the_list.lookup( id, result );
  
  if ( result ) {
      SC_REPORT_ERROR( SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, 
                       "terminal already added to the link" );
  }
  the_list.insert( id, intf );
}

//-----------------------------------------------------------------------
sc_self_binding_port::~sc_self_binding_port( )
{

}

//-----------------------------------------------------------------------
void
sc_self_binding_port::add_attribute_b( sc_self_binding_attribute_b *data, int id )
{
  sc_self_binding_attribute_b** result = 0;
  attribute_list.lookup( id, result );
  
  if ( result ) {
      SC_REPORT_ERROR( SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_, 
                       "attribute already added to the link" );
  }
  attribute_list.insert( id, data );
}

//-----------------------------------------------------------------------
const char*
get_ms_lib_version( )
{
  static const char* ver = "2.0.1";
  return ver;
}

