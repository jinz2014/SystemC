/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2001 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License Version 2.2 (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.systemc.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

/*****************************************************************************

  sc_master_slave.cpp -- Master / Slave ports.

  Original Author: Dirk Vermeersch, Coware, Inc.
                   Vijay Kumar, Coware, Inc.

*****************************************************************************/


#include "sc_ms_ids.h"
#include "systemc/utils/sc_report.h"

// ----------------------------------------------------------------------------
//  Report ids (M/S library)
//
//  Report ids in the range of 1000-1099..
// ----------------------------------------------------------------------------

const int SC_ID_MS_INCOMPATIBLE_PORT_PROTOCOL_ON_LINKMP_ 	= 1000;
const int SC_ID_MS_INVALID_INTERFACE_				= 1001;
const int SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_		= 1002;
const int SC_ID_MS_BIND_SB_ATTRIBUTE_				= 1003;
const int SC_ID_MS_INDEX_OUT_OF_RANGE_				= 1004;
const int SC_ID_MS_MULTIPLE_WRITE_TO_LINK_                      = 1005;

static 
int
initialize( )
{
  sc_report::register_id( SC_ID_MS_INCOMPATIBLE_PORT_PROTOCOL_ON_LINKMP_,
			  "incompatible port protocols" );
  sc_report::register_id( SC_ID_MS_INVALID_INTERFACE_,
			  "invalid interface for port" );
  sc_report::register_id( SC_ID_MS_INCORRECT_VALENCY_SB_TERMINAL_,
			  "incorrect valency of self binding terminals" );
  sc_report::register_id( SC_ID_MS_BIND_SB_ATTRIBUTE_,
			  "bind attribute to link failed" );
  sc_report::register_id( SC_ID_MS_INDEX_OUT_OF_RANGE_,
			  "index out of range" );
  sc_report::register_id( SC_ID_MS_MULTIPLE_WRITE_TO_LINK_,
			  "cannot write twice to the same link" );
  return 5;
}

static int sc_ms_error_msg_initialize = initialize();
