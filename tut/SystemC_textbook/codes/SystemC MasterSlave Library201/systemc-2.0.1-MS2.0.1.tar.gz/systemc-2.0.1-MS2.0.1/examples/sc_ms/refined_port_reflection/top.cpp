#include "systemc.h"
#include "sc_mslib.h"

// test the port to port reflection of refined ports

typedef sc_inslave<int, sc_enableHandshake<int> >	input_port;
typedef sc_link_mp<int >				binding_link;

SC_MODULE( disp ) {
    input_port din;
    SC_CTOR( disp ) {
    }
};

SC_MODULE( bbox ) {
    input_port bb_din;
    disp       disp1;

    SC_CTOR( bbox )
	: disp1("display") {
	//bb_din( disp1.din );
	
	disp1.din( bb_din );
    }
};

SC_MODULE( top ) {
    sc_in_clk		clk;
    binding_link 	sig;
    bbox		black_box;
    int			x;
    bool		b;

    void func( ) {
	// read values from port, this should not fail
	x = black_box.bb_din.d;
	b = black_box.bb_din.en;

	cout << "read values from port " << endl;
    }
	
    SC_CTOR( top )
	: black_box("bbox")	{
	black_box.bb_din( sig );
	SC_METHOD( func );
	sensitive << clk;
    }
};

int
sc_main( int, char ** )
{
    top t("top" );
    sc_clock	clk("clk", 5);
    t.clk( clk );

    cout << "Test the refined port to port reflection of refined ports"
	 << endl;

    sc_initialize( );

    sc_start( 5 );
    return 0;
};
    
