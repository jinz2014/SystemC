//main programme
#include "hello.h"
int sc_main(int i, char* av[]){
hello h("hello");
return 0;
}