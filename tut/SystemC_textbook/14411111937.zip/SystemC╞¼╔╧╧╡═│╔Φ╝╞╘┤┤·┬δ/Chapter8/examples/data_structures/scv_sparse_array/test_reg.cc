#include "test.cc"

#ifdef NCSC
SC_MODULE_EXPORT(sctop)
#endif
