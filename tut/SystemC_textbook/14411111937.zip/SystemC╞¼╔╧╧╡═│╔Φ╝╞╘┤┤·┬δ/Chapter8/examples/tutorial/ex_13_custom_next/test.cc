#include "test.h"

// nbinclude "main" start
int sc_main(int argc, char** argv) {
  test t("test");
  sc_start(-1);
  return (0);
}
// nbinclude "main" end

