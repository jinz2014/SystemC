struct data_t {
  int         field_1;
  sc_uint<8>  field_2;
  unsigned    payload[5];
  string      str;
};
