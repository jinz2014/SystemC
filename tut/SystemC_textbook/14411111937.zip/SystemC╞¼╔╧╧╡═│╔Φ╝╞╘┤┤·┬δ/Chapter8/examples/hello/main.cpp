#include "scv.h"

int sc_main(int argc, char** argv) {
  cout << "Hello, world!" << endl;
  return 0;
}
