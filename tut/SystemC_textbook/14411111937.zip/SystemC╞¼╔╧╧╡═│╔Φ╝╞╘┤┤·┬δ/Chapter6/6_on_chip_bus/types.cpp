//By Chenxi
// only needed for more readable debug output
char status_str[4][20] = {"TRANSFER_OK" 
                          , "TRANSFER_REQUEST"
                          , "TRANSFER_WAIT"
                          , "TRANSFER_ERROR"};
