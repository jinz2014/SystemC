#include <systemc.h>
#include "driving.h"
int sc_main(int, char**){
Tristate Tri("Tri");	
	return 0;
}